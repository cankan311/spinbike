# Japan Ride D26 Claude OFM + 3D Below Recenter

D26変更点:
- 3D ON/OFFボタンを現在地マークの下に配置
- 現在地マークと3Dボタンを右側に縦並び
- Claude方式 / OpenFreeMap / 地理院航空写真 / D10 UI は維持

GitHub Pagesでは `index.html` を公開してください。
