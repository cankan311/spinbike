# Japan Ride D27 3D Button Definite

D27変更点:
- 3D ON/OFFを現在地マークの真下に独立したボタンとして常時表示
- z-indexを大きくし、UIや地図の下に隠れないように修正
- 初期表示: 3D OFF
- ON時: 青背景の 3D ON
- Claude方式 / OpenFreeMap / 地理院航空写真 / D10 UI は維持

GitHub Pagesでは `index.html` を公開してください。
